 ___               __          
(_  _ _ _ _  _  _/(  _ _ / _ _ 
/  / (/(///)(-/)/__)(-(-/((-/  
      _/                       

Version 15 November 2010

USAGE: java [-Xmx1G] -jar FragmentSeeker.jar [-partialFragments:false] [-maxCombination:1000] [-maxMappings:1000] [-flushToDiskEvery:100] [-resumeDir:previousDirPath] [-exactFrequencies:true] [-removeTmpFiles:true] [-compressTmpFiles:true] [-extractCoverFragments:true] [-outputPath:null] [-trainUK:-1] treebankFile

*   make sure you have installed a java version 1.5 or above (from a terminal type java -version);
*   -Xmx1G -> max amount of memory reserved for the program (depending on the size of the treebank G=GygaBytes, M=Megabytes)
*   -partialFragments:false -> extract partial fragments [default false]
*   -maxCombination:1000 ->  set the maximum number of combinations between the partial fragment of a specific mapping of daughters (valid only if partialFragments is active) [default 1000]
*   -maxMappings:1000 -> set the maximum number of mappings when comparing the daughters of two nodes (valid only if partialFragments is active) [default 1000]
*   -exactFrequencies:true -> count the exact frequencies of the extracted (partial) fragments [default false]
*	-flushToDiskEvery:100 -> set the number of trees after which the program flushes the extracted fragments to disk (default 100) 
*	-resumeDir:previousDirPath -> in case the program was interrupted you can use this option to resume the work
*	-removeTmpFiles:true -> whether to remove temporary files (default true)
*	-compressTmpFiles:true -> whether to compress output of temporary files (necessary for partial fragments where the files get huge easily)
*	-extractCoverFragments:true -> whether to extract cover fragments after extracting recurring fragments (default true, but works only for fragments right now)
*	-threads:1 -> how many threads to run (makes the work a lot fast on a multi-CPU machine, mind the memory though)
*	-outputPath:null -> specifies the output dir (default the same dir where treebankFile is).
*   treebankFile -> a file with PS structures in Penn format, such as treebankExample.mrg

A new directory FragmentSeeker_{currentDateAndTime} will be created in the same directory of the treebankFile (or outputPath if specified), and several files will be created within this directory reporting information related to the extracted fragments.

Example of usage:
   From the same directory where the file FragmentSeeker.jar type:
   java -jar FragmentSeeker.jar treebankExample.mrg
	
For any question or suggestion please contact Federico Sangati (f.sangati@uva.nl).

Reference:
Federico Sangati, Willem Zuidema and Rens Bod. 
Efficiently extract recurring tree fragments from large treebanks.
Proceedings LREC 2010, Malta.