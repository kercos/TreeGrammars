
/*******************************************************************/
/*                                                                 */
/*     File: wordclass.h                                           */
/*   Author: Helmut Schmid                                         */
/*                                                                 */
/*******************************************************************/

#include <stdio.h>
#include <vector>
using std::vector;

class Transition {
public:
  char character;
  int  target;

  Transition( char c, int t ) { character = c; target = t; };
};

class State {
public:
  int wordclass;
  vector<Transition> transition;

  State( int c=0 ) { wordclass = c; };
};

class Automaton {
private:
  vector<State> state;

public:
  Automaton(FILE*);
  int wordclass( const char *s, int state=0 );
  int number_of_classes;
};
