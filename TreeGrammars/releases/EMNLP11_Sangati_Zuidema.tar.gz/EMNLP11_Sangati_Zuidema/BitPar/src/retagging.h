/*******************************************************************/
/*      File: /home/helmut/src/BitPar/retagging.h                  */
/*    Author: Helmut Schmid                                        */
/*   Purpose:                                                      */
/*   Created: Tue Apr  1 12:07:46 2003                             */
/*  Modified: Tue Apr  1 12:21:29 2003 (helmut)                    */
/* Copyright: Institut fuer maschinelle Sprachverarbeitung         */
/*            Universitaet Stuttgart                               */
/*******************************************************************/

#include "baseparser.h"
#include "tree.h"

void init_tagging( Grammar &g, Lexicon &l );
void process( Tree* );
