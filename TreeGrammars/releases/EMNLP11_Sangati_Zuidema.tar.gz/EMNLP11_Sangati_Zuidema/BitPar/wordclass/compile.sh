#!/bin/sh

perl update-indices.perl wordclass.fst
fst-compiler wordclass.fst wordclass.a
fst-print wordclass.a | perl convert-automaton.perl > wordclass.txt
